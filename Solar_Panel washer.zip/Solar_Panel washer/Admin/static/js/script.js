function navigate(page) {
    window.location.href = page;
  }
  