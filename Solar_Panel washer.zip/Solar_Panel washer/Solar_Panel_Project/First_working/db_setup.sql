CREATE DATABASE solar_washer;

USE solar_washer;

CREATE TABLE auto_wash (
    id INT AUTO_INCREMENT PRIMARY KEY,
    wash_time DATETIME
);

CREATE TABLE manual_wash (
    id INT AUTO_INCREMENT PRIMARY KEY,
    wash_time DATETIME
);
