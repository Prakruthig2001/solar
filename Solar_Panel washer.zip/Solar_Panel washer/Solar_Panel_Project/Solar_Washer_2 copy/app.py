from flask import Flask, render_template, request, redirect, jsonify
from flask_mysqldb import MySQL
import datetime

app = Flask(__name__)

# Configure DB
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Anjali@123'
app.config['MYSQL_DB'] = 'solar_washer'

mysql = MySQL(app)

@app.route('/')
def auto():
    cur = mysql.connection.cursor()
    cur.execute("SELECT wash_time FROM auto_wash ORDER BY wash_time DESC LIMIT 5")
    history = cur.fetchall()
    cur.execute("SELECT wash_time FROM auto_wash ORDER BY wash_time DESC LIMIT 1")
    last = cur.fetchone()
    next_time = (last[0] + datetime.timedelta(days=3)) if last else "Not scheduled"
    return render_template('auto.html', last=last, next_time=next_time, history=history)

@app.route('/manual', methods=['GET', 'POST'])
def manual():
    if request.method == 'POST':
        duration = int(request.form['duration'])

        wash_time = datetime.datetime.now()
        date = wash_time.date()
        time = wash_time.time()

        start_time = time
        stop_time = (wash_time + datetime.timedelta(minutes=duration)).time()

        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO manual_wash (wash_time, duration, date, time, start_time, stop_time)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (wash_time, duration, date, time, start_time, stop_time))
        mysql.connection.commit()

        return jsonify(success=True)

    # Fetch last 5 manual wash records
    cur = mysql.connection.cursor()
    cur.execute("SELECT wash_time, duration, date, time, start_time, stop_time FROM manual_wash ORDER BY wash_time DESC LIMIT 5")
    history = cur.fetchall()

    # Get latest wash time
    cur.execute("SELECT wash_time FROM manual_wash ORDER BY wash_time DESC LIMIT 1")
    last = cur.fetchone()

    # Format times
    formatted_history = []
    for h in history:
        start_time = h[4].strftime('%H:%M') if hasattr(h[4], 'strftime') else str(h[4])[:5]
        stop_time = h[5].strftime('%H:%M') if hasattr(h[5], 'strftime') else str(h[5])[:5]
        formatted_history.append((h[0], h[1], h[2], h[3], start_time, stop_time))

    return render_template('manual.html', last=last, history=formatted_history)

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)