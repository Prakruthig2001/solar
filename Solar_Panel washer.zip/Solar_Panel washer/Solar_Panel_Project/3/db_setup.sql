CREATE TABLE auto_wash (
    id INT AUTO_INCREMENT PRIMARY KEY,
    wash_date DATE,
    start_time TIME,
    stop_time TIME,
    duration INT, -- in minutes
    interval_days INT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE manual_wash (
    id INT AUTO_INCREMENT PRIMARY KEY,
    wash_time DATETIME,
    duration INT,
    date DATE,
    time TIME
);
ALTER TABLE manual_wash
ADD COLUMN start_time TIME AFTER time,
ADD COLUMN stop_time TIME AFTER start_time;