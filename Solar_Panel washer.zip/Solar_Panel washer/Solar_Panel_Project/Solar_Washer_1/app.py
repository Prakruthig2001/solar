from flask import Flask, render_template, request, redirect, jsonify
import mysql.connector
from datetime import datetime

app = Flask(__name__)

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Anjali@123",
    database="solarwasher"
)

cursor = db.cursor()

@app.route('/')
def home():
    cursor.execute("SELECT * FROM auto_wash ORDER BY date DESC LIMIT 5")
    auto_history = cursor.fetchall()
    cursor.execute("SELECT date FROM auto_wash ORDER BY date DESC LIMIT 1")
    last_auto = cursor.fetchone()
    next_auto = datetime.now().strftime('%Y-%m-%d')  # Replace with logic
    return render_template("index.html", last_auto=last_auto, next_auto=next_auto, history=auto_history)

@app.route('/manual', methods=["GET", "POST"])
def manual():
    if request.method == "POST":
        selected_time = request.form['wash_time']
        cursor.execute("INSERT INTO manual_wash (date) VALUES (%s)", (selected_time,))
        db.commit()
        return jsonify({'status': 'success'})
    
    cursor.execute("SELECT * FROM manual_wash ORDER BY date DESC LIMIT 5")
    manual_history = cursor.fetchall()
    cursor.execute("SELECT date FROM manual_wash ORDER BY date DESC LIMIT 1")
    last_manual = cursor.fetchone()
    return render_template("manual.html", last_manual=last_manual, history=manual_history)

@app.route('/about')
def about():
    return render_template("about.html")

if __name__ == '__main__':
    app.run(debug=True)
