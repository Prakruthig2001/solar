from flask import Flask, render_template, request, jsonify
from flask_mysqldb import MySQL
import datetime
from apscheduler.schedulers.background import BackgroundScheduler

app = Flask(__name__)

# Configure DB
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Anjali@123'
app.config['MYSQL_DB'] = 'solar_washer'

mysql = MySQL(app)

# 🧠 Background Task Function
def check_and_run_auto_wash():
    with app.app_context():
        cur = mysql.connection.cursor()
        current_time = datetime.datetime.now().time()
        current_date = datetime.datetime.now().date()

        # Deactivate any washes whose stop_time has passed
        cur.execute("""
            UPDATE auto_wash SET is_active = FALSE
            WHERE is_active = TRUE AND stop_time < %s AND wash_date <= %s
        """, (current_time, current_date))
        mysql.connection.commit()

        # Check whether new wash is due
        if datetime.time(19, 0) <= current_time or current_time <= datetime.time(7, 0):
            cur.execute("SELECT * FROM auto_wash ORDER BY id DESC LIMIT 1")
            last = cur.fetchone()
            if last:
                last_date = last[1]  # wash_date
                interval = last[5]   # interval_days
                next_date = last_date + datetime.timedelta(days=interval)

                if current_date >= next_date:
                    start_time = datetime.datetime.now()
                    duration = last[4]
                    stop_time = start_time + datetime.timedelta(minutes=duration)

                    cur.execute("""
                        INSERT INTO auto_wash (wash_date, start_time, stop_time, duration, interval_days, is_active)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """, (start_time.date(), start_time.time(), stop_time.time(), duration, interval, True))
                    mysql.connection.commit()

        cur.close()


# 🌐 AUTO ROUTE
@app.route('/auto', methods=['GET', 'POST'])
def auto():
    cur = mysql.connection.cursor()

    if request.method == 'POST':
        duration = int(request.form['duration'])
        interval = int(request.form['interval'])

        start_time = datetime.datetime.now()
        stop_time = start_time + datetime.timedelta(minutes=duration)
        wash_date = start_time.date()

        # Insert wash with is_active = TRUE
        cur.execute("""
            INSERT INTO auto_wash (wash_date, start_time, stop_time, duration, interval_days, is_active)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (wash_date, start_time.time(), stop_time.time(), duration, interval, True))
        mysql.connection.commit()
        return jsonify(success=True)

    # --- Load last wash details ---
    cur.execute("SELECT duration, wash_date, start_time, stop_time, is_active FROM auto_wash ORDER BY id DESC LIMIT 1")
    record = cur.fetchone()
    washing_now = False

    if record:
        duration, date, start_time, stop_time, is_active = record
        now = datetime.datetime.now().time()

    # Convert if needed
        if isinstance(start_time, datetime.timedelta):
            start_time = (datetime.datetime.min + start_time).time()
        if isinstance(stop_time, datetime.timedelta):
            stop_time = (datetime.datetime.min + stop_time).time()

        washing_now = is_active and start_time <= now <= stop_time


    # --- Compute next scheduled wash ---
    cur.execute("SELECT wash_date, interval_days FROM auto_wash ORDER BY id DESC LIMIT 1")
    last = cur.fetchone()
    next_time = ""
    if last:
        last_date = last[0]
        interval = last[1]
        next_time = last_date + datetime.timedelta(days=interval)

    # --- Get last 5 history ---
    cur.execute("SELECT duration, wash_date, start_time, stop_time FROM auto_wash ORDER BY id DESC LIMIT 5")
    history = cur.fetchall()

    formatted_history = []
    for record in history:
        duration, date, start_time, stop_time = record
        start_str = start_time.strftime("%H:%M") if isinstance(start_time, datetime.time) else str(start_time)
        stop_str = stop_time.strftime("%H:%M") if isinstance(stop_time, datetime.time) else str(stop_time)
        formatted_history.append((duration, date, start_str, stop_str))

    cur.close()
    return render_template('auto.html', last=last, next_time=next_time, history=formatted_history, washing_now=washing_now)

# 🌐 MANUAL ROUTE
@app.route('/manual', methods=['GET', 'POST'])
def manual():
    if request.method == 'POST':
        duration = int(request.form['duration'])

        wash_time = datetime.datetime.now()
        date = wash_time.date()
        time = wash_time.time()

        start_time = time
        stop_time = (wash_time + datetime.timedelta(minutes=duration)).time()

        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO manual_wash (wash_time, duration, date, time, start_time, stop_time)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (wash_time, duration, date, time, start_time, stop_time))
        mysql.connection.commit()

        return jsonify(success=True)

    cur = mysql.connection.cursor()
    cur.execute("SELECT wash_time, duration, date, time, start_time, stop_time FROM manual_wash ORDER BY wash_time DESC LIMIT 5")
    history = cur.fetchall()

    cur.execute("SELECT wash_time FROM manual_wash ORDER BY wash_time DESC LIMIT 1")
    last = cur.fetchone()

    formatted_history = []
    for h in history:
        start_time = h[4].strftime('%H:%M') if hasattr(h[4], 'strftime') else str(h[4])[:5]
        stop_time = h[5].strftime('%H:%M') if hasattr(h[5], 'strftime') else str(h[5])[:5]
        formatted_history.append((h[0], h[1], h[2], h[3], start_time, stop_time))

    return render_template('manual.html', last=last, history=formatted_history)


@app.route('/about')
def about():
    return render_template('about.html')

# ✅ ENTRY POINT
if __name__ == '__main__':
    # 🔁 Start scheduler only after app context is ready
    scheduler = BackgroundScheduler()
    scheduler.add_job(func=check_and_run_auto_wash, trigger="interval", minutes=1)
    scheduler.start()

    app.run(debug=True)