from flask import Flask, request, jsonify, render_template
from datetime import datetime, timedelta
from flask_cors import CORS
import mysql.connector

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

def get_db_connection():
    global conn
    try:
        if conn.is_connected():
            return conn
    except:
        pass

# Connect to MySQL
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='Anjali@123',
    database='solar_wash',
    ssl_disabled=True,
    connection_timeout=300  # 5 minutes
)

@app.route('/')
def home():
    return render_template("index.html")


@app.route('/wash/manual', methods=['POST'])
def manual_wash():
    try:
        duration = request.json.get('duration', 5)
        cursor = get_db_connection().cursor()
        cursor.execute("INSERT INTO wash_history (type, duration) VALUES (%s, %s)", ('manual', duration))
        get_db_connection().commit()
        cursor.close()
        return jsonify({'message': 'Manual wash started', 'duration': duration}), 200
    except Exception as e:
        print("❌ Error in /wash/manual:", e)
        return jsonify({'error': str(e)}), 500


@app.route('/wash/auto', methods=['POST'])
def auto_wash():
    try:
        cursor1 = get_db_connection().cursor(dictionary=True)
        cursor1.execute("SELECT MAX(timestamp) as last FROM wash_history WHERE type = 'auto'")
        result = cursor1.fetchone()
        last_wash = result['last'] if result else None
        cursor1.close()

        cursor2 = get_db_connection().cursor(dictionary=True)
        cursor2.execute("SELECT schedule_interval FROM settings WHERE id = 1")
        interval_result = cursor2.fetchone()
        cursor2.close()

        interval = interval_result['schedule_interval'] if interval_result else None
        now = datetime.now()

        if not interval:
            return jsonify({'error': 'Schedule interval not set'}), 500

        if not last_wash or (now - last_wash).days >= interval:
            cursor3 = get_db_connection.cursor()
            cursor3.execute("INSERT INTO wash_history (type, duration) VALUES (%s, %s)", ('auto', 5))
            get_db_connection().commit()
            cursor3.close()
            return jsonify({'message': 'Automatic wash triggered'}), 200
        else:
            return jsonify({'message': 'Wash not due yet'}), 400

    except Exception as e:
        print("❌ Error in /wash/auto:", e)
        return jsonify({'error': str(e)}), 500


@app.route('/wash/interval', methods=['POST'])
def set_interval():
    try:
        new_interval = request.json.get('interval')
        if new_interval in [7, 15]:
            cursor = get_db_connection().cursor()
            cursor.execute("UPDATE settings SET schedule_interval = %s WHERE id = 1", (new_interval,))
            get_db_connection().commit()
            cursor.close()
            return jsonify({'message': f'Schedule interval updated to {new_interval} days'}), 200
        return jsonify({'error': 'Invalid interval. Choose 7 or 15.'}), 400
    except Exception as e:
        print("❌ Error in /wash/interval:", e)
        return jsonify({'error': str(e)}), 500


@app.route('/wash/next', methods=['GET'])
def get_next_wash():
    try:
        cursor1 = get_db_connection().cursor(dictionary=True)
        cursor1.execute("SELECT MAX(timestamp) as last FROM wash_history WHERE type = 'auto'")
        result = cursor1.fetchone()
        cursor1.close()
        last_wash = result['last'] if result and result['last'] else None

        cursor2 = get_db_connection().cursor(dictionary=True)
        cursor2.execute("SELECT schedule_interval FROM settings WHERE id = 1")
        interval_result = cursor2.fetchone()
        cursor2.close()
        interval = interval_result['schedule_interval'] if interval_result else None

        if not interval:
            return jsonify({'error': 'Schedule interval not found'}), 500

        if last_wash:
            next_due = last_wash + timedelta(days=interval)
            return jsonify({'next_due': next_due.isoformat()}), 200
        else:
            return jsonify({'message': 'No automatic wash has been recorded yet'}), 200

    except Exception as e:
        print("❌ Error in /wash/next:", e)
        return jsonify({'error': str(e)}), 500


@app.route('/wash/history', methods=['GET'])
def get_history():
    try:
        cursor = get_db_connection().cursor(dictionary=True)
        cursor.execute("SELECT * FROM wash_history ORDER BY timestamp DESC")
        history = cursor.fetchall()
        cursor.close()
        return jsonify(history), 200
    except Exception as e:
        print("❌ Error in /wash/history:", e)
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
