const API_BASE = "http://127.0.0.1:5000";

function startManualWash() {
  const duration = document.getElementById("manualDuration").value;
  fetch(`${API_BASE}/wash/manual`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ duration: parseInt(duration) })
  })
  .then(async res => {
    const data = await res.json();
    if (res.ok) {
      alert(data.message);
      fetchHistory();
      fetchNext();
    } else {
      alert("❌ Error: " + (data.error || "Something went wrong"));
    }
  })
  .catch(err => {
    console.error("❌ Manual wash failed:", err);
    alert("❌ Could not connect to the server.");
  });
  
}

function triggerAutoWash() {
  fetch(`${API_BASE}/wash/auto`, { method: "POST" })
    .then(res => res.json())
    .then(data => {
      alert(data.message);
      fetchHistory();
      fetchNext();
    });
}

function setIntervalDays() {
  const interval = document.getElementById("interval").value;
  fetch(`${API_BASE}/wash/interval`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ interval: parseInt(interval) })
  })
    .then(res => res.json())
    .then(data => alert(data.message));
}

function fetchNext() {
  fetch(`${API_BASE}/wash/next`)
    .then(res => res.json())
    .then(data => {
      const next = data.next_due || data.message;
      document.getElementById("nextWash").textContent = next;
    });
}

function fetchHistory() {
  fetch(`${API_BASE}/wash/history`)
    .then(res => res.json())
    .then(data => {
      const list = document.getElementById("historyList");
      list.innerHTML = "";

      if (!Array.isArray(data)) {
        console.error("❌ Expected array but got:", data);
        list.innerHTML = "<li>Error loading history</li>";
        return;
      }

      data.forEach(entry => {
        const item = document.createElement("li");
        item.textContent = `${entry.timestamp} - ${entry.type} (${entry.duration} min)`;
        list.appendChild(item);
      });
    })
    .catch(err => {
      console.error("❌ fetchHistory failed:", err);
    });
}


// Initial load
fetchHistory();
fetchNext();
