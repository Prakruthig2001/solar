from flask import Flask, render_template, request, redirect, jsonify,flash, url_for
from flask_mysqldb import MySQL
import datetime
from apscheduler.schedulers.background import BackgroundScheduler

app = Flask(__name__)

app.secret_key = 'Prakruthi'


# Configure DB
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Anjali@123'
app.config['MYSQL_DB'] = 'solar_washer'

mysql = MySQL(app)

@app.route('/')
def index():
    return redirect('/auto')

def check_and_run_auto_washes():
    with app.app_context():
        cur = mysql.connection.cursor()

        # Get original user-created washes
        cur.execute("""
            SELECT id, wash_date, start_time, interval_days, duration
            FROM auto_wash
            WHERE generated = 0 AND is_cancelled = FALSE
        """)

        originals = cur.fetchall()

        today = datetime.date.today()

        for wash in originals:
            wash_id, first_date, start_time, interval_days, duration = wash

            # Get the most recent generated wash for this origin
            cur.execute("""
                SELECT MAX(wash_date) FROM auto_wash
                WHERE origin_id = %s
            """, (wash_id,))
            last_gen_date = cur.fetchone()[0]

            if last_gen_date is None:
                last_gen_date = first_date

            next_run_date = last_gen_date + datetime.timedelta(days=interval_days)

            if today >= next_run_date:
                start_datetime = datetime.datetime.combine(next_run_date, start_time)
                stop_datetime = start_datetime + datetime.timedelta(minutes=duration)

                cur.execute("""
                    INSERT INTO auto_wash (wash_date, start_time, stop_time, duration, interval_days, origin_id, generated)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """, (next_run_date, start_time, stop_datetime.time(), duration, interval_days, wash_id, True))
                mysql.connection.commit()

        cur.close()

@app.route('/auto', methods=['GET', 'POST'])
def auto():
    cur = mysql.connection.cursor()

    if request.method == 'POST':
        duration = int(request.form['duration'])
        interval = int(request.form['interval'])
        start_time_str = request.form['start_time']
        
        if not start_time_str:
            return jsonify(success=False, message="Start date and time are required.")
        
        # Parse full datetime (e.g., 2025-05-06T02:00)
        start_datetime = datetime.datetime.strptime(start_time_str, "%Y-%m-%dT%H:%M")
        hour = start_datetime.hour

        # Restrict to 7 PM to 7 AM
        if not (hour >= 19 or hour < 7):
            return jsonify(success=False, message="Washes can only be scheduled between 7 PM and 7 AM.")

        stop_datetime = start_datetime + datetime.timedelta(minutes=duration)
        wash_date = start_datetime.date()

         # Insert into DB
        cur.execute("""
            INSERT INTO auto_wash (wash_date, start_time, stop_time, duration, interval_days)
            VALUES (%s, %s, %s, %s, %s)
        """, (wash_date, start_datetime.time(), stop_datetime.time(), duration, interval))
        mysql.connection.commit()

        return jsonify(success=True)

     # Fetch last wash
    cur.execute("SELECT wash_date, start_time FROM auto_wash ORDER BY id DESC LIMIT 1")
    last = cur.fetchone()
    next_time = ""
    if last:
        last_date = last[0]
        cur.execute("SELECT interval_days FROM auto_wash ORDER BY id DESC LIMIT 1")
        interval = cur.fetchone()[0]
        next_date = last_date + datetime.timedelta(days=interval)
        days_remaining = (next_date - datetime.date.today()).days
        if days_remaining > 0:
            next_time = f"in {days_remaining} day{'s' if days_remaining > 1 else ''}"
        else:
            next_time = "today"

    # Fetch last 5 history
    cur.execute("SELECT duration, wash_date, start_time, stop_time, status FROM auto_wash ORDER BY id DESC LIMIT 5")
    history = cur.fetchall()

    formatted_history = []
    for record in history:
        duration, date, start_time, stop_time, status = record
        start_str = start_time.strftime("%H:%M") if isinstance(start_time, datetime.time) else str(start_time)
        stop_str = stop_time.strftime("%H:%M") if isinstance(stop_time, datetime.time) else str(stop_time)
        formatted_history.append((duration, date, start_str, stop_str, status))


    cur.close()
    return render_template('auto.html', last=last, next_time=next_time, history=formatted_history)

@app.route('/manual', methods=['GET', 'POST'])
def manual():
    if request.method == 'POST':
        current_hour = datetime.datetime.now().hour
        # Allow only between 7 PM and 7 AM
        if not (current_hour >= 19 or current_hour < 7):
            return jsonify(success=False, message="Manual Mode is only available between 7 PM and 7 AM.")

        duration = int(request.form['duration'])
        wash_time = datetime.datetime.now()
        date = wash_time.date()
        time = wash_time.time()

        start_time = time
        stop_time = (wash_time + datetime.timedelta(minutes=duration)).time()

        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO manual_wash (wash_time, duration, date, time, start_time, stop_time)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (wash_time, duration, date, time, start_time, stop_time))
        mysql.connection.commit()

        return jsonify(success=True)

    # Fetch last 5 manual wash records
    cur = mysql.connection.cursor()
    cur.execute("SELECT wash_time, duration, date, time, start_time, stop_time FROM manual_wash ORDER BY wash_time DESC LIMIT 5")
    history = cur.fetchall()

    # Get latest wash time
    cur.execute("SELECT wash_time FROM manual_wash ORDER BY wash_time DESC LIMIT 1")
    last = cur.fetchone()

    # Format times
    formatted_history = []
    for h in history:
        start_time = h[4].strftime('%H:%M') if hasattr(h[4], 'strftime') else str(h[4])[:5]
        stop_time = h[5].strftime('%H:%M') if hasattr(h[5], 'strftime') else str(h[5])[:5]
        formatted_history.append((h[0], h[1], h[2], h[3], start_time, stop_time))

    return render_template('manual.html', last=last, history=formatted_history)

@app.route('/cancel_auto', methods=['POST'])
def cancel_auto():
    cur = mysql.connection.cursor()
    # Find the latest ungenerated auto_wash entry
    cur.execute("""
        SELECT id FROM auto_wash 
        WHERE `generated` = 0 
        ORDER BY id DESC LIMIT 1
    """)
    row = cur.fetchone()
    
    if row:
        auto_id = row[0]
        # Update the entry to indicate it has been canceled
        cur.execute("""
            UPDATE auto_wash 
            SET is_active = 1, `generated` = 1, status = 'canceled', is_cancelled = TRUE
            WHERE id = %s
        """, (auto_id,))
        mysql.connection.commit()
        flash('Auto wash was successfully canceled.', 'success')
    else:
        flash('No active auto wash found to cancel.', 'warning')
    
    return redirect(url_for('auto'))
@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=4500)
    scheduler = BackgroundScheduler()
    scheduler.add_job(func=check_and_run_auto_washes, trigger="interval", hours=24)  # runs daily
    scheduler.start()

    try:
        app.run(debug=True)
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()
