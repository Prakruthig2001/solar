CREATE DATABASE solar_washer;

USE solar_washer;

CREATE TABLE auto_wash (
    id INT AUTO_INCREMENT PRIMARY KEY,
    wash_date DATE,
    start_time TIME,
    stop_time TIME,
    duration INT,
    interval_days INT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT FALSE,
    origin_id INT DEFAULT NULL,
    `generated` TINYINT DEFAULT 1,
    is_cancelled BOOLEAN DEFAULT FALSE,
    status ENUM('pending', 'completed', 'skipped') DEFAULT 'pending'
);
ALTER TABLE auto_wash MODIFY COLUMN status ENUM('pending', 'completed', 'skipped', 'canceled') DEFAULT 'pending';

UPDATE auto_wash 
SET is_active = 0, `generated` = 1, status = 'canceled', is_cancelled = TRUE 
WHERE id = 123; -- use a real id

SELECT id, status FROM auto_wash WHERE id = 123;


CREATE TABLE manual_wash (
    id INT AUTO_INCREMENT PRIMARY KEY,
    wash_time DATETIME,
    duration INT,
    date DATE,
    time TIME
);
ALTER TABLE manual_wash
ADD COLUMN start_time TIME AFTER time,
ADD COLUMN stop_time TIME AFTER start_time;