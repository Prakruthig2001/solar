from flask import Flask, render_template, request, redirect, jsonify
from flask_mysqldb import MySQL
import datetime

app = Flask(__name__)

# Configure DB
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Anjali@123'
app.config['MYSQL_DB'] = 'solar_washer'

mysql = MySQL(app)

@app.route('/')
def index():
    return redirect('/auto')

@app.route('/auto', methods=['GET', 'POST'])
def auto():
    cur = mysql.connection.cursor()

    if request.method == 'POST':
        duration = int(request.form['duration'])
        interval = int(request.form['interval'])

        start_time = datetime.datetime.now()
        stop_time = start_time + datetime.timedelta(minutes=duration)
        wash_date = start_time.date()

        cur.execute("""
            INSERT INTO auto_wash (wash_date, start_time, stop_time, duration, interval_days)
            VALUES (%s, %s, %s, %s, %s)
        """, (wash_date, start_time.time(), stop_time.time(), duration, interval))
        mysql.connection.commit()
        return jsonify(success=True)

    # Initialize variables to avoid UnboundLocalError
    last = None
    next_time = ""
    history = []

    # Fetch last wash
    cur.execute("SELECT wash_date, start_time FROM auto_wash ORDER BY id DESC LIMIT 1")
    last = cur.fetchone()
    if last:
        last_date = last[0]
        # Get interval_days from the same latest record
        cur.execute("SELECT interval_days FROM auto_wash ORDER BY id DESC LIMIT 1")
        interval = cur.fetchone()[0]
        next_date = last_date + datetime.timedelta(days=interval)
        days_remaining = (next_date - datetime.date.today()).days
        if days_remaining > 0:
            next_time = f"in {days_remaining} day{'s' if days_remaining > 1 else ''}"
        else:
            next_time = "today"


    # Fetch last 5 auto wash history
    cur.execute("SELECT duration, wash_date, start_time, stop_time FROM auto_wash ORDER BY id DESC LIMIT 5")
    history = cur.fetchall()

    # Format start_time and stop_time for display
    formatted_history = []
    for record in history:
        duration, date, start_time, stop_time = record
        start_str = start_time.strftime("%H:%M") if isinstance(start_time, datetime.time) else str(start_time)
        stop_str = stop_time.strftime("%H:%M") if isinstance(stop_time, datetime.time) else str(stop_time)
        formatted_history.append((duration, date, start_str, stop_str))

    cur.close()

    return render_template('auto.html', last=last, next_time=next_time, history=formatted_history)

@app.route('/manual', methods=['GET', 'POST'])
def manual():
    if request.method == 'POST':
        current_hour = datetime.datetime.now().hour
        # Allow only between 7 PM and 7 AM
        if not (current_hour >= 19 or current_hour < 7):
            return jsonify(success=False, message="Manual Mode is only available between 7 PM and 7 AM.")

        duration = int(request.form['duration'])
        wash_time = datetime.datetime.now()
        date = wash_time.date()
        time = wash_time.time()

        start_time = time
        stop_time = (wash_time + datetime.timedelta(minutes=duration)).time()

        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO manual_wash (wash_time, duration, date, time, start_time, stop_time)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (wash_time, duration, date, time, start_time, stop_time))
        mysql.connection.commit()

        return jsonify(success=True)

    # Fetch last 5 manual wash records
    cur = mysql.connection.cursor()
    cur.execute("SELECT wash_time, duration, date, time, start_time, stop_time FROM manual_wash ORDER BY wash_time DESC LIMIT 5")
    history = cur.fetchall()

    # Get latest wash time
    cur.execute("SELECT wash_time FROM manual_wash ORDER BY wash_time DESC LIMIT 1")
    last = cur.fetchone()

    # Format times
    formatted_history = []
    for h in history:
        start_time = h[4].strftime('%H:%M') if hasattr(h[4], 'strftime') else str(h[4])[:5]
        stop_time = h[5].strftime('%H:%M') if hasattr(h[5], 'strftime') else str(h[5])[:5]
        formatted_history.append((h[0], h[1], h[2], h[3], start_time, stop_time))

    return render_template('manual.html', last=last, history=formatted_history)



@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)